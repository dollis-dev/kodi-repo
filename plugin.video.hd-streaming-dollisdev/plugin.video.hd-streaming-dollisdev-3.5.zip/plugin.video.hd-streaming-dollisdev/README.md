# plugin.video.hd-streaming-dollisdev
Modded version of the orginal plugin.video.hd-streaming Kodi addon
